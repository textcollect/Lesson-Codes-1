package org.generation.fsdwebdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FsdwebdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FsdwebdemoApplication.class, args);
	}

}
